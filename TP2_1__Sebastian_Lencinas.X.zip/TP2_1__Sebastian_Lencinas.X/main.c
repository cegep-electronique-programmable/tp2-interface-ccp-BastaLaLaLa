#include "mcc_generated_files/mcc.h"

/*
                         Main application
 */
typedef enum {              //Tout les etats possible dans le programme    
    initial, barrer, debarrer, L, U, autre  
}Etat; 

void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();

    uint8_t touche;

    Etat etat = initial;

    while (1)
    {
        switch(etat){           //etat initial, on attend que l'utilisateur
            case initial:       //appuie une touche
   
                printf("L pour barrer\n\r");
                printf("U pour barrer\n\r");

                if(EUSART1_Read()== 'L'){
                    etat= L;
                }
                else if(EUSART1_Read()== 'U'){
                    etat= U;
                }
                else{
                    etat=autre;
                }
                break;                         //Fin de la sequence
                
            case L:
                PWM2_LoadDutyValue(65);
                printf("barrer\n\r");
                etat=initial;
                break;
                
            case U:                
                PWM2_LoadDutyValue(19);
                printf("debarrer\n\r");
                etat=initial;
                break;
            
            case autre:
                printf("ressayez\n\r");
                etat=initial;
          
            default:
                etat=initial;   //revenir a l'etat initial
        }
    }
}

