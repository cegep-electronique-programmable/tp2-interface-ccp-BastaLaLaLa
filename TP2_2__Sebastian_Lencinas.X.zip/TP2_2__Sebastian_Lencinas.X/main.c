#include "mcc_generated_files/mcc.h"

/*
                         Main application
 */
 

uint16_t Capture;
int i= 1;

void clear(void){               //Sequence pour effacer le LCD 
    EUSART1_Write(0xFE);        //clear screen
    EUSART1_Write(0x51);
    
    EUSART1_Write(0xFE);        //ajuster au caractere 0 
    EUSART1_Write(0x45);
    EUSART1_Write(0x00);
}

void Capture_Callback(uint16_t capturedValue) {
        CCP2CON = 0x04; // Capture sur front descendant
        Capture= capturedValue;  // total de la dur�e haute
        TMR1_WriteTimer(0); // R�initialiser Timer1 apr�s chaque mesure       
}

void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();
    INTERRUPT_GlobalInterruptDisable();
    INTERRUPT_PeripheralInterruptEnable();
    
    CCP2_SetCallBack(Capture_Callback);     //activer le input capture de la fonction CaptureCallBack

    while (1)
    {
        clear();                        // Clear screen
        printf("T: %u us", Capture);    // affichage de la valeur de la periode
        __delay_ms(500);
    }
}

